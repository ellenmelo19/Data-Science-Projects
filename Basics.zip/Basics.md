# Meu primeiro projeto de Data Science

## Fuga de Helicóptero!

Começamos importando algumas funções de ajuda


```python
from helper import *
```

## Coleta dos dados

Agora, vamos coletar os dados da lista 


```python
url = 'https://en.wikipedia.org/wiki/List_of_helicopter_prison_escapes'

data = data_from_url(url)
```

Imprimindo as três primeiras colunas:


```python
for row in data:
    print(row[:3])
```

    ['August 19, 1971', 'Santa Martha Acatitla', 'Mexico']
    ['October 31, 1973', 'Mountjoy Jail', 'Ireland']
    ['May 24, 1978', 'United States Penitentiary, Marion', 'United States']
    ['February 27, 1981', 'Fleury-Mérogis, Essonne, Ile de France', 'France']
    ['May 7, 1981', 'Orsainville Prison, Quebec City', 'Canada']
    ['January, 1983', 'Pentridge (HM Prison)', 'Australia']
    ['December 19, 1985', 'Perry Correctional Institution, Pelzer, South Carolina', 'United States']
    ['December 31, 1985', 'Cândido Mendes penitentiary, Ilha Grande, Rio de Janeiro', 'Brazil']
    ['May 26, 1986', 'Prison de la Santé', 'France']
    ['November 5, 1986', 'Federal Correctional Institution, Dublin', 'United States']
    ['November 23, 1986', 'Prigione di Rebibbia, Roma', 'Italy']
    ['December 10, 1987', 'Gartree (HM Prison)', 'United Kingdom']
    ['July 11, 1988', 'Santa Fe prison', 'United States']
    ['April 17, 1989', 'Federal Holding Facility, Miami, FL', 'United States']
    ['August 19, 1989', 'Arkansas Valley Correctional Facility', 'United States']
    ['June 19, 1990', 'Kent Penitentiary, British Columbia', 'Canada']
    ['1991', 'Rio Piedras State Penitentiary, Puerto Rico', 'Puerto Rico']
    ['1992', 'Lyon Prison', 'France']
    ['December 1992', 'Touraine Central Prison, Tours', 'France']
    ['June 17, 1993', 'Touraine Central Prison, Tours', 'France']
    ['December 30, 1996', 'High Security Prison, Santiago', 'Chile']
    ['September 18, 1997', 'De Geerhorst jail', 'Netherlands']
    ['March 25, 1999', 'Metropolitan Remand and Reception Centre', 'Australia']
    ['June 5, 2000', 'Martin Treatment Center for Sexually Violent Predators, Martin County Florida', 'United States']
    ['2000', 'Lyon prison', 'France']
    ['2001', 'Luynes prison', 'France']
    ['March 24, 2001', 'Draguignan prison', 'France']
    ['May 28, 2001', 'Fresnes prison', 'France']
    ['January 17, 2002', 'Parada Neto Penitentiary', 'Brazil']
    ['December 30, 2002', 'Las Cucharas prison, Puerto Rico', 'United States']
    ['2003', 'Luynes prison', 'France']
    ['July 2005', 'France', 'France']
    ['December 10, 2005', 'Aiton Prison', 'France']
    ['June 6, 2006', 'Korydallos Prison', 'Greece']
    ['April 15, 2007', 'Lantin Prison, Liège', 'Belgium']
    ['July 15, 2007', 'Grasse prison', 'France']
    ['October 28, 2007', 'Ittre prison', 'Belgium']
    ['February 22, 2009', 'Korydallos Prison', 'Greece']
    ['April 27, 2009', 'Domenjod Prison, Réunion', 'France']
    ['July 23, 2009', 'Bruges', 'Belgium']
    ['June 25, 2010', 'HM Prison Isle of Wight, Isle of Wight', 'United Kingdom']
    ['March 22, 2012', 'Sheksna, Penal colony N17', 'Russia']
    ['February 24, 2013', 'Trikala Prison, Trikala', 'Greece']
    ['March 17, 2013', 'Saint-Jérôme Detention Facility, Quebec', 'Canada']
    ['June 7, 2014', 'Orsainville Detention Facility, Quebec', 'Canada']
    ['February 22, 2016', 'Thiva', 'Greece']
    ['July 1, 2018', 'Réau, near Paris', 'France']
    ['September 25, 2020', 'Forest prison, Brussels', 'Belgium']


## Retirando os 'Detalhes'


Inicializamos uma variável chamada `index` de valor `0`. O propósito de criar essa variável é para nos ajudar a saber qual coluna estamos modificando.


```python
index = 0

for row in data:
    data[index] = row[:-1]
    index += 1
```


```python
print(data[:3])
```

    [['August 19, 1971', 'Santa Martha Acatitla', 'Mexico', 'Yes', 'Joel David Kaplan Carlos Antonio Contreras Castro', "Joel David Kaplan was a New York businessman who had been arrested for murder in 1962 in Mexico City and was incarcerated at the Santa Martha Acatitla prison in the Iztapalapa borough of Mexico City. Joel's sister, Judy Kaplan, arranged the means to help Kaplan escape, and on August 19, 1971, a helicopter landed in the prison yard. The guards mistakenly thought this was an official visit. In two minutes, Kaplan and his cellmate Carlos Antonio Contreras, a Venezuelan counterfeiter, were able to board the craft and were piloted away, before any shots were fired.[9] Both men were flown to Texas and then different planes flew Kaplan to California and Castro to Guatemala.[3] The Mexican government never initiated extradition proceedings against Kaplan.[9] The escape is told in a book, The 10-Second Jailbreak: The Helicopter Escape of Joel David Kaplan.[4] It also inspired the 1975 action movie Breakout, which starred Charles Bronson and Robert Duvall.[9]"], ['October 31, 1973', 'Mountjoy Jail', 'Ireland', 'Yes', "JB O'Hagan Seamus TwomeyKevin Mallon", 'On October 31, 1973 an IRA member hijacked a helicopter and forced the pilot to land in the exercise yard of Dublin\'s Mountjoy Jail\'s D Wing at 3:40\xa0p.m., October 31, 1973. Three members of the IRA were able to escape: JB O\'Hagan, Seamus Twomey and Kevin Mallon. Another prisoner who also was in the prison was quoted as saying, "One shamefaced screw apologised to the governor and said he thought it was the new Minister for Defence (Paddy Donegan) arriving. I told him it was our Minister of Defence leaving." The Mountjoy helicopter escape became Republican lore and was immortalized by "The Helicopter Song", which contains the lines "It\'s up like a bird and over the city. There\'s three men a\'missing I heard the warder say".[1]'], ['May 24, 1978', 'United States Penitentiary, Marion', 'United States', 'No', 'Garrett Brock TrapnellMartin Joseph McNallyJames Kenneth Johnson', "43-year-old Barbara Ann Oswald hijacked a Saint Louis-based charter helicopter and forced the pilot to land in the yard at USP Marion. While landing the aircraft, the pilot, Allen Barklage, who was a Vietnam War veteran, struggled with Oswald and managed to wrestle the gun away from her. Barklage then shot and killed Oswald, thwarting the escape.[10] A few months later Oswald's daughter hijacked TWA Flight 541 in an effort to free Trapnell."]]


## Extraindo o ano


Vamos extrair o ano, recursivamente , da coluna.

 Assim, `date = fetch_year(row[0])`, é a extração do ano da data em `row[0]` e atribuição à variável `date`.
Depois, substituímos o valor de `row[0]` pelo ano que acabamos de extrair.


```python
from helper import *

url = 'https://en.wikipedia.org/wiki/List_of_helicopter_prison_escapes'
data = data_from_url(url)

for row in data:
    date = fetch_year(row[0])
    row[0] = date
```


```python
print(data[:3])
```

    [[1971, 'Santa Martha Acatitla', 'Mexico', 'Yes', 'Joel David Kaplan Carlos Antonio Contreras Castro', "Joel David Kaplan was a New York businessman who had been arrested for murder in 1962 in Mexico City and was incarcerated at the Santa Martha Acatitla prison in the Iztapalapa borough of Mexico City. Joel's sister, Judy Kaplan, arranged the means to help Kaplan escape, and on August 19, 1971, a helicopter landed in the prison yard. The guards mistakenly thought this was an official visit. In two minutes, Kaplan and his cellmate Carlos Antonio Contreras, a Venezuelan counterfeiter, were able to board the craft and were piloted away, before any shots were fired.[9] Both men were flown to Texas and then different planes flew Kaplan to California and Castro to Guatemala.[3] The Mexican government never initiated extradition proceedings against Kaplan.[9] The escape is told in a book, The 10-Second Jailbreak: The Helicopter Escape of Joel David Kaplan.[4] It also inspired the 1975 action movie Breakout, which starred Charles Bronson and Robert Duvall.[9]"], [1973, 'Mountjoy Jail', 'Ireland', 'Yes', "JB O'Hagan Seamus TwomeyKevin Mallon", 'On October 31, 1973 an IRA member hijacked a helicopter and forced the pilot to land in the exercise yard of Dublin\'s Mountjoy Jail\'s D Wing at 3:40\xa0p.m., October 31, 1973. Three members of the IRA were able to escape: JB O\'Hagan, Seamus Twomey and Kevin Mallon. Another prisoner who also was in the prison was quoted as saying, "One shamefaced screw apologised to the governor and said he thought it was the new Minister for Defence (Paddy Donegan) arriving. I told him it was our Minister of Defence leaving." The Mountjoy helicopter escape became Republican lore and was immortalized by "The Helicopter Song", which contains the lines "It\'s up like a bird and over the city. There\'s three men a\'missing I heard the warder say".[1]'], [1978, 'United States Penitentiary, Marion', 'United States', 'No', 'Garrett Brock TrapnellMartin Joseph McNallyJames Kenneth Johnson', "43-year-old Barbara Ann Oswald hijacked a Saint Louis-based charter helicopter and forced the pilot to land in the yard at USP Marion. While landing the aircraft, the pilot, Allen Barklage, who was a Vietnam War veteran, struggled with Oswald and managed to wrestle the gun away from her. Barklage then shot and killed Oswald, thwarting the escape.[10] A few months later Oswald's daughter hijacked TWA Flight 541 in an effort to free Trapnell."]]


## Tentativas por ano

Criar uma lista de listas com dois elementos: ano e tentativas.

Primeiros e últimos anos:


```python
min_year = min(data, key=lambda x: x[0])[0]
max_year = max(data, key=lambda x: x[0])[0]
```

Vamos criar uma lista dos anos variando do menor ao maior. Assim iremos determinar quantas tentativas de fuga da prisão ocorreram em cada ano.


```python
years = []
for y in range(min_year, max_year + 1):
    years.append(y)
```

Agora criamos uma lista onde cada elemento é `[<year>, 0].`


```python
attempts_per_year = []
for y in years:
    attempts_per_year.append([y, 0])
```

Por fim, acrescentamos à entrada (de índice 1) +1 cada vez que um ano aparece nos dados.


```python
# Para cada coluna em data
for row in data:
    for ya in attempts_per_year:
        y = ya[0]
        
        #Atribuir o valor do ano em ya para y
        if row[0] == y:
            ya[1] += 1
            
#Imprimir os resultados            
print(attempts_per_year)  
```

    [[1971, 1], [1972, 0], [1973, 1], [1974, 0], [1975, 0], [1976, 0], [1977, 0], [1978, 1], [1979, 0], [1980, 0], [1981, 2], [1982, 0], [1983, 1], [1984, 0], [1985, 2], [1986, 3], [1987, 1], [1988, 1], [1989, 2], [1990, 1], [1991, 1], [1992, 2], [1993, 1], [1994, 0], [1995, 0], [1996, 1], [1997, 1], [1998, 0], [1999, 1], [2000, 2], [2001, 3], [2002, 2], [2003, 1], [2004, 0], [2005, 2], [2006, 1], [2007, 3], [2008, 0], [2009, 3], [2010, 1], [2011, 0], [2012, 1], [2013, 2], [2014, 1], [2015, 0], [2016, 1], [2017, 0], [2018, 1], [2019, 0], [2020, 1]]


Em que ano ocorreram mais tentativas de fuga da prisão com um helicóptero?


```python
%matplotlib inline
barplot(attempts_per_year)
```


    
![png](output_29_0.png)
    


R: Os anos em que ocorreram mais tentativas de fuga de helicóptero foram 1986, 2001, 2007 e 2009, com três tentativas cada.

E se quiséssemos responder à pergunta: 
Em quais países ocorrem as mais tentativas de fuga de helicóptero?

# Tentativas por país

Em nossos dados, cada país pode aparecer várias vezes. Assim vamos contar quantas vezes cada país aparece, respondendo assim à pergunta.


```python
#Contar o número de ocorrências para cada país
countries_frequency = df["Country"].value_counts()
```


```python
print_pretty_table(countries_frequency)
```


<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Country</th>
      <th>Number of Occurrences</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>France</td>
      <td>15</td>
    </tr>
    <tr>
      <td>United States</td>
      <td>8</td>
    </tr>
    <tr>
      <td>Canada</td>
      <td>4</td>
    </tr>
    <tr>
      <td>Belgium</td>
      <td>4</td>
    </tr>
    <tr>
      <td>Greece</td>
      <td>4</td>
    </tr>
    <tr>
      <td>Brazil</td>
      <td>2</td>
    </tr>
    <tr>
      <td>United Kingdom</td>
      <td>2</td>
    </tr>
    <tr>
      <td>Australia</td>
      <td>2</td>
    </tr>
    <tr>
      <td>Italy</td>
      <td>1</td>
    </tr>
    <tr>
      <td>Netherlands</td>
      <td>1</td>
    </tr>
    <tr>
      <td>Chile</td>
      <td>1</td>
    </tr>
    <tr>
      <td>Ireland</td>
      <td>1</td>
    </tr>
    <tr>
      <td>Russia</td>
      <td>1</td>
    </tr>
    <tr>
      <td>Puerto Rico</td>
      <td>1</td>
    </tr>
    <tr>
      <td>Mexico</td>
      <td>1</td>
    </tr>
  </tbody>
</table>


Concluímos então que o país com mais tentativas de fuga de prisão por helicóptero é a França.


```python

```
